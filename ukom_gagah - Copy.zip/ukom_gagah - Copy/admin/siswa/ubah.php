<?php
include "../../includes/koneksi.php";

$id = $_POST['id_user'];
$nama = $_POST['nama'];
$nis = $_POST['nis'];
$email = $_POST['email'];
$id_kelas = $_POST['id_kelas'];

if(!empty($_POST['password'])){
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    mysqli_query($koneksi,"UPDATE tb_user SET password='$pass' WHERE id_user='$id'");
}

mysqli_query($koneksi,"
UPDATE tb_user SET
nama='$nama',
nis='$nis',
email='$email',
id_kelas='$id_kelas'
WHERE id_user='$id'
");

header("location:index.php?msg=1");
