<?php
if (session_status() == PHP_SESSION_NONE) session_start();
$menu = $_SESSION['menu'] ?? '';
?>

<nav class="navbar navbar-expand-lg navbar-light bg-primary shadow-sm fixed-top">
  <div class="container-fluid">

    <!-- Brand -->
    <a class="navbar-brand fw-bold text-light" href="dashboard.php">
      <i class="bi bi-chat-dots-fill"></i> Aduin
    </a>

    <!-- Hamburger Button -->
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSiswa">
      <span class="navbar-toggler-icon"></span>
    </button>

    <!-- Menu -->
    <div class="collapse navbar-collapse" id="navbarSiswa">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0 gap-lg-2">

        <li class="nav-item mb-2">
          <a class="nav-link <?= ($menu=='dashboard')?'active fw-bold text-primary':'' ?>" href="dashboard.php">
            <i class="bi bi-speedometer2"></i> Dashboard
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?= ($menu=='aspirasi')?'active fw-bold text-primary':'' ?>" href="aspirasi.php">
            <i class="bi bi-pencil-square"></i> Aspirasi
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?= ($menu=='histori')?'active fw-bold text-primary':'' ?>" href="histori.php">
            <i class="bi bi-clock-history"></i> Histori
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?= ($menu=='feedback')?'active fw-bold text-primary':'' ?>" href="feedback.php">
            <i class="bi bi-chat-left-text"></i> Feedback
          </a>
        </li>

        <li class="nav-item">
          <a class="nav-link <?= ($menu=='profil')?'active fw-bold text-primary':'' ?>" href="profil_siswa.php">
            <i class="bi bi-person-circle"></i> Profil
          </a>
        </li>

        <li class="nav-item">
          <a class="btn btn-outline-danger ms-lg-2" href="../logout.php">
            <i class="bi bi-box-arrow-right"></i> Logout
          </a>
        </li>

      </ul>
    </div>
  </div>
</nav>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<!-- Spacer biar konten gak ketutup navbar -->
<div style="height:70px;"></div>
