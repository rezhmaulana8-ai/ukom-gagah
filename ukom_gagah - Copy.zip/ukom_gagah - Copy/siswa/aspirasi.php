<?php
// koneksi database
include "../includes/koneksi.php"; // pastikan file ini ada dan berisi koneksi mysqli
session_start();
include "../includes/navbarSiswa.php";
// contoh ambil id user dari session login
$id_user = $_SESSION['id_user'] ?? 1; // fallback 1 jika belum ada sistem login

if (isset($_POST['simpan'])) {
    $id_kategori  = $_POST['id_kategori'];
    $lokasi       = $_POST['lokasi'];
    $isi_aspirasi = $_POST['isi_aspirasi'];

    $query = "INSERT INTO tb_aspirasi (id_user, id_kategori, lokasi, isi_aspirasi, status)
              VALUES ('$id_user', '$id_kategori', '$lokasi', '$isi_aspirasi', 'menunggu')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Aspirasi berhasil dikirim');window.location='dashboard.php';</script>";
    } else {
        echo "<script>alert('Gagal menyimpan data');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Form Aspirasi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <div class="card shadow">
        <div class="card-header text-center fw-bold">
            Form Aspirasi Siswa
        </div>
        <div class="card-body">
            <form method="POST">

                <!-- Kategori -->
                <div class="mb-3">
                    <label class="form-label">Kategori</label>
                    <select name="id_kategori" class="form-select" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php
                        $kat = mysqli_query($koneksi, "SELECT * FROM tb_kategori");
                        while($k = mysqli_fetch_assoc($kat)){
                            echo "<option value='{$k['id_kategori']}'>{$k['nama_kategori']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <!-- Lokasi -->
                <div class="mb-3">
                    <label class="form-label">Lokasi</label>
                    <input type="text" name="lokasi" class="form-control" placeholder="Contoh: Ruang Lab Komputer" required>
                </div>

                <!-- Isi Aspirasi -->
                <div class="mb-3">
                    <label class="form-label">Isi Aspirasi</label>
                    <textarea name="isi_aspirasi" class="form-control" rows="4" placeholder="Tuliskan aspirasi anda..." required></textarea>
                </div>

                <button type="submit" name="simpan" class="btn btn-primary w-100">Kirim Aspirasi</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>
