<?php
session_start();
$_SESSION['menu'] = "dashboard";



if (!isset($_SESSION['role']) || $_SESSION['role'] != 'siswa') {
  
}

include "../includes/koneksi.php";
include "../includes/navbarSiswa.php";

$id_user = $_SESSION['id_user'];

// hitung data aspirasi
$total = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_aspirasi WHERE id_user='$id_user'"));
$menunggu = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_aspirasi WHERE id_user='$id_user' AND status='menunggu'"));
$proses = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_aspirasi WHERE id_user='$id_user' AND status='proses'"));
$selesai = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM tb_aspirasi WHERE id_user='$id_user' AND status='selesai'"));
?>

<!DOCTYPE html>
<html lang="id">
<head>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">

<style>
body{
    background: linear-gradient(180deg, #0077b6, #0096c7, #48cae4);
    min-height:100vh;
}

/* layout utama */
.main-content{
    margin-left:240px;
    padding:20px;
    transition:.3s;
}

/* responsive */
@media(max-width:768px){
    .main-content{
        margin-left:0;
        padding:15px;
    }
}
</style>

</head>
<body class="bg-light">
  <button class="btn btn-light d-md-none position-fixed top-0 start-0 m-2 shadow"
        data-bs-toggle="offcanvas" 
        data-bs-target="#sidebarSiswa">
    <i class="bi bi-list fs-4"></i>
</button>


  

<div class="container mt-5 pt-4">
  <h4 class="fw-bold mb-4">Halo, <?php echo $_SESSION['nama']; ?> 👋</h4>

  <div class="row g-3">

    <div class="col-md-3">
      <div class="card shadow text-center">
        <div class="card-body">
          <h6>Total Aspirasi</h6>
          <h2 class="fw-bold"><?php echo $total['total']; ?></h2>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card shadow text-center border-warning">
        <div class="card-body">
          <h6>Menunggu</h6>
          <h2 class="fw-bold text-warning"><?php echo $menunggu['total']; ?></h2>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card shadow text-center border-primary">
        <div class="card-body">
          <h6>Diproses</h6>
          <h2 class="fw-bold text-primary"><?php echo $proses['total']; ?></h2>
        </div>
      </div>
    </div>

    <div class="col-md-3">
      <div class="card shadow text-center border-success">
        <div class="card-body">
          <h6>Selesai</h6>
          <h2 class="fw-bold text-success"><?php echo $selesai['total']; ?></h2>
        </div>
      </div>
    </div>

  </div>

  <div class="card shadow mt-4">
    <div class="card-header fw-bold">Aspirasi Terbaru</div>
    <div class="card-body">
      <table class="table table-striped">
        <tr>
          <th>Lokasi</th>
          <th>Isi</th>
          <th>Status</th>
          <th>Tanggal</th>
        </tr>
        <?php
        $q = mysqli_query($koneksi, "SELECT * FROM tb_aspirasi WHERE id_user='$id_user' ORDER BY created_at DESC LIMIT 5");
        while($d = mysqli_fetch_assoc($q)){
        ?>
        <tr>
          <td><?php echo $d['lokasi']; ?></td>
          <td><?php echo $d['isi_aspirasi']; ?></td>
          <td>
            <span class="badge bg-<?php echo $d['status']=='menunggu'?'warning':($d['status']=='proses'?'primary':'success'); ?>">
              <?php echo $d['status']; ?>
            </span>
          </td>
          <td><?php echo date('d-m-Y', strtotime($d['created_at'])); ?></td>
        </tr>
        <?php } ?>
      </table>
    </div>
  </div>

</div>
  <!-- ISI DASHBOARD KAMU -->


</body>
</html>
